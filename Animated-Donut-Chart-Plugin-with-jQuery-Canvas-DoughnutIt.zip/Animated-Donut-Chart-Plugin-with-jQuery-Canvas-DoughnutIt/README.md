doughnutIt
==========

Jquery plugin using Chart.js to create awesome Doughnuts Charts with some text inside and around it


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/JusCezari/doughnutit/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

